# KOTE Multi Asset — Private Cloud V1.8

A private, password-protected web deployment of the existing virtual dashboard. This is **not** a brokerage account or real-money transaction system.

## Publish on Render (requires your own Render and GitHub accounts)

1. Create a **private GitHub repository** and upload these files to its root: `app.py`, `dashboard.html`, `requirements.txt`, `render.yaml`.
2. Sign into Render and choose **New > Blueprint**; connect the private GitHub repository and deploy its `render.yaml`.
3. When prompted for `KOTE_PASSWORD`, enter a **unique password of at least 12 characters**. Do not add the password to GitHub or share it in ChatGPT. Username defaults to `kote`.
4. Wait for Render to report deployment complete. Open the HTTPS `onrender.com` URL provided by Render and enter your credentials.
5. Click **Sync NAVs & recalculate**. Check Evidence & system health to confirm 4/4 NAV histories.

**Hosting notes:** Render's pricing and plan availability can change. The Blueprint specifies `starter`, which may incur a charge. This ZIP does not create a public website automatically. Browser HTTP Basic authentication is protected by Render HTTPS in transit, but has no multi-factor authentication, login lockout, or user management; use a unique password and do not share the URL publicly. For sensitive personal financial records, a stronger identity provider (SSO/MFA) and audited infrastructure are recommended before uploading them.

NAV histories are fetched from a third-party AMFI-derived service. The server caches NAVs locally, but hosted cache may be ephemeral; restarting/redeploying may clear it. The dashboard calculations are client-side; user settings are not persisted across devices. No account or portfolio transaction data is uploaded to a database. Always verify fund scheme mappings, NAVs, restrictions, tax and SWP assumptions.

## Local development test

```sh
python -m pip install -r requirements.txt
# set KOTE_PASSWORD in your shell to a private 12+ character password
python app.py
```

Then open http://localhost:8505/. Never run Flask's development server publicly; use the provided Gunicorn production command on the host.
