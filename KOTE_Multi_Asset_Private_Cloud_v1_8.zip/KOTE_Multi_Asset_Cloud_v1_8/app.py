import base64
import hashlib
import hmac
import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from flask import Flask, Response, request, send_file, jsonify

app = Flask(__name__)
BASE = Path(__file__).resolve().parent
CACHE = Path(os.getenv('KOTE_CACHE_DIR', str(BASE / 'nav_cache')))
CACHE.mkdir(parents=True, exist_ok=True)
TTL = 12 * 3600
PASSWORD = os.getenv('KOTE_PASSWORD', '')
USERNAME = os.getenv('KOTE_USERNAME', 'kote')
if not PASSWORD or len(PASSWORD) < 12:
    raise RuntimeError('Set KOTE_PASSWORD environment variable to a strong password (12+ characters).')

def authenticated():
    auth = request.authorization
    return bool(auth and hmac.compare_digest(auth.username or '', USERNAME) and hmac.compare_digest(auth.password or '', PASSWORD))

@app.before_request
def guard():
    if request.path == '/healthz':
        return None
    if not authenticated():
        return Response('Authentication required', 401, {'WWW-Authenticate': 'Basic realm="KOTE Private Dashboard"', 'Cache-Control': 'no-store'})

@app.after_request
def security_headers(resp):
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['X-Frame-Options'] = 'DENY'
    resp.headers['Referrer-Policy'] = 'no-referrer'
    resp.headers['Cache-Control'] = 'no-store'
    return resp

@app.get('/healthz')
def health():
    return jsonify(status='ok')

@app.get('/')
def dashboard():
    return send_file(BASE / 'dashboard.html', mimetype='text/html')

@app.get('/api/mf/<path:tail>')
def nav(tail):
    if tail == 'search':
        q = request.args.get('q', '').strip()
        if not q or len(q) > 120:
            return jsonify(error='Invalid search query'), 400
        query = urlencode({'q': q})
        url = 'https://api.mfapi.in/mf/search?' + query
        key = 'search_' + hashlib.sha256(query.encode()).hexdigest()[:24]
    elif re.fullmatch(r'\d{1,11}', tail):
        url = 'https://api.mfapi.in/mf/' + tail
        key = 'fund_' + tail
    else:
        return jsonify(error='Invalid scheme code'), 400
    cache_file = CACHE / (key + '.json')
    if cache_file.is_file() and time.time() - cache_file.stat().st_mtime < TTL:
        return Response(cache_file.read_bytes(), mimetype='application/json', headers={'X-KOTE-Data-Status':'cached'})
    try:
        req = Request(url, headers={'User-Agent': 'KOTE-Multi-Asset/1.8', 'Accept': 'application/json'})
        with urlopen(req, timeout=20) as upstream:
            data = upstream.read(12 * 1024 * 1024 + 1)
        if len(data) > 12 * 1024 * 1024:
            raise ValueError('NAV response too large')
        json.loads(data)
        temp = cache_file.with_suffix('.tmp')
        temp.write_bytes(data)
        temp.replace(cache_file)
        return Response(data, mimetype='application/json', headers={'X-KOTE-Data-Status':'updated'})
    except Exception:
        if cache_file.is_file():
            return Response(cache_file.read_bytes(), mimetype='application/json', headers={'X-KOTE-Data-Status':'stale-offline'})
        return jsonify(error='NAV provider unavailable; no cached data for this request'), 503

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=int(os.getenv('PORT', '8505')))
